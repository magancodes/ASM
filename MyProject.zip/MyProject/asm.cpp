/*
						TITLE : Claims 				 
						
						NAME  	        : Nakshatra Kanchan
						ROLL NUMBER     : 2302CS10
						Declaration of Authorship:
						This txt file is part of the assignment of the course CS2102cat at 
						Department of Computer Science and Engineering, IIT Patna .  
*/


#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <unordered_map>
#include <iomanip>
#include <algorithm>

using namespace std;


struct ErrorDetail {
    int position;
    string message;
    bool operator< (const ErrorDetail &other) const {
        return position < other.position;
    }
};

struct WarningDetail {
    int position;
    string message;
    bool operator< (const WarningDetail &other) const {
        return position < other.position;
    }
};

struct LineData {
    int programCounter;
    string labelName;
    string operation;
    string operandValue;
};

struct ListingData {
    string address;
    string machineCode;
    string statement;
};

vector<ErrorDetail> errorDetails; 
vector<WarningDetail> warningDetails; 
vector<LineData> lineRecords; 
vector<ListingData> listingRecords; 
vector<string> machineCodes;

map<string, pair<int, int>> labelAddressMap; 
map<string, pair<string, int>> instructionMap; 
map<string, vector<int>> labelUsageMap; 
map<string, string> variableMap; 
vector<string> readInstructions;

bool checkIfNumeric(char c) {
    static const char digits[] = "0123456789";
    int i = 0;
    while (digits[i] != '\0') {
        if (c == digits[i]) {
            return true;
        }
        ++i;
    }
    return false;
}

bool checkIfAlphabet(char character) 
{
    char loweredChar = tolower(character);
    const string letters = "abcdefghijklmnopqrstuvwxyz";

    for (char letter : letters) 
    {
        if (loweredChar == letter) 
        {
            return true;
        }
    }
    return false;
}

bool validateLabel(string name) 
{
    bool labelIsValid = checkIfAlphabet(name.at(0));  // Check if the first character is an alphabet

    // Iterate through each character in the string starting from the second character
    for (size_t position = 1; position < name.size(); ++position) 
    {
        char current = name.at(position);
        // Verify that each character is alphanumeric or an underscore
        if (!(isalnum(current) || current == '_')) 
        {
            labelIsValid = false;
            break;
        }
    }
    return labelIsValid;
}

bool CheckIfDecimal(const std::string& input) {
    bool isValid = true;
    int status = 1;

    for (size_t index = 0; index < input.length(); ++index) {
        char currentChar = input[index];

        // Check if the character is not a digit
        if (currentChar < '0' || currentChar > '9') {
            status = 0;
            break;
        }
    }

    // Return true if all characters were digits, false otherwise
    return (status == 1);
}

bool CheckIfOctal(const string& octalNum) {
    bool valid = true;

    // Ensure the string has more than one character and starts with '0'
    if (octalNum.length() < 2 || octalNum[0] != '0') {
        return false;
    }

    // Verify that each character falls between '0' and '7'
    for (size_t i = 1; i < octalNum.length(); ++i) {
        if (octalNum[i] < '0' || octalNum[i] > '7') {
            return false;
        }
    }

    return true;
}

bool CheckIfHex(string hexStr) 
{
    if (hexStr.length() < 3 || hexStr.front() != '0' || (tolower(hexStr.at(1)) != 'x')) 
    {
        return false;  // Check if it starts with "0x" or "0X" and has sufficient length
    }

    // Loop through each character after the "0x" prefix
    for (size_t i = 2; i < hexStr.length(); i++) 
    {
        char current = std::tolower(hexStr[i]);
        if (!std::isxdigit(current)) 
        {
            return false;
        }
    }
    return true;
}
string convertOctalToDecimal(const string& octalStr) {
    int decimalValue = 0;
    int base = 1; // This represents 8^0, 8^1, etc.

    // Process the octal string from the last character to the first
    for (int index = octalStr.length() - 1; index >= 0; --index) {
        // Convert character to its integer value
        int currentDigit = octalStr[index] - '0';

        // Update the total decimal value
        decimalValue += currentDigit * base;

        // Update base for the next digit
        base *= 8;
    }

    // Return the decimal value as a string
    return to_string(decimalValue);
}

string convertHexToDecimal(const string& hexStr) {
    int decimalValue = 0;
    int base = 1; // This will represent 16^0, 16^1, etc.

    // Process the hexadecimal string from the last character to the first
    for (int idx = hexStr.length() - 1; idx >= 0; --idx) {
        char currentChar = hexStr[idx];
        int currentDigitValue;

        // Determine the value of the current hexadecimal character
        if (isdigit(currentChar)) {
            currentDigitValue = currentChar - '0';
        } else {
            currentDigitValue = tolower(currentChar) - 'a' + 10;
        }

        // Update the total decimal value
        decimalValue += currentDigitValue * base;
        base *= 16; // Increase base for the next digit
    }

    // Return the decimal value as a string
    return to_string(decimalValue);
}

string convertDecimalToHex(int inputDecimal) {
    unsigned int value = inputDecimal; // Use unsigned to handle larger values
    string hexOutput = "";

    // Process the number for up to 8 hexadecimal digits
    for (int idx = 0; idx < 8; ++idx) {
        int remainder = value % 16; // Get the remainder when divided by 16
        char hexCharacter;

        // Determine the appropriate character for the hex digit
        if (remainder < 10) {
            hexCharacter = static_cast<char>(remainder + '0'); // Convert to character
        } else {
            hexCharacter = static_cast<char>(remainder - 10 + 'A'); // Convert to character for A-F
        }

        hexOutput += hexCharacter; // Append the hex character to the output string
        value /= 16; // Divide by 16 for the next iteration
    }

    reverse(hexOutput.begin(), hexOutput.end()); // Reverse the string to get correct order
    return hexOutput;
}

string extractFileName(const std::string& input) 
{
    string fileName;
    int positionOfDot = -1;

    // Find the position of the first dot
    for (size_t pos = 0; pos < input.size(); ++pos) 
    {
        if (input[pos] == '.') 
        {
            positionOfDot = static_cast<int>(pos);
            break;
        }
    }

    // If a dot was found, extract the substring up to the dot's position
    if (positionOfDot != -1) 
    {
        fileName = input.substr(0, positionOfDot);
    }
    else 
    {
        fileName = input; // No dot found, take the entire string
    }

    return fileName;
}

int main(int argc, char** args) 
{
    // Validate the number of arguments provided
    if (argc != 2) 
    {
        cout << "Error: Incorrect file naming format.\n";
        return 0;
    }

    // Extract file name and open input file stream
    string filename = extractFileName(args[1]);
    ifstream fileStream(args[1]);
    if (!fileStream.is_open() || fileStream.peek() == std::ifstream::traits_type::eof()) 
    {
        cout << "Error: File is empty or cannot be opened.\n";
        return 0;
    }

    // Read instructions from file
    vector<string> instructions;
    string line;
    while (getline(fileStream, line)) 
    {
        instructions.push_back(line);
    }
    fileStream.close();

    // Initialize the operand table
    instructionMap = {
        {"data", {"", 1}}, {"ldc", {"00", 1}}, {"adc", {"01", 1}},
        {"ldl", {"02", 2}}, {"stl", {"03", 2}}, {"ldnl", {"04", 2}},
        {"stnl", {"05", 2}}, {"add", {"06", 0}}, {"sub", {"07", 0}},
        {"shl", {"08", 0}}, {"shr", {"09", 0}}, {"adj", {"0A", 1}},
        {"a2sp", {"0B", 0}}, {"sp2a", {"0C", 0}}, {"call", {"0D", 2}},
        {"return", {"0E", 0}}, {"brz", {"0F", 2}}, {"brlz", {"10", 2}},
        {"br", {"11", 2}}, {"HALT", {"12", 0}}, {"SET", {"", 1}}
    };

    // Parse and process each instruction line
    int lineNumber = 0;
    int programCounter = 0;
    bool haltFound = false;

    for (const auto& instr : instructions) 
    {
        lineNumber++;
        if (instr.empty()) continue;

        // Parse instruction
        vector<string> tokens;
        stringstream ss(instr);
        string part;
        while (ss >> part) 
        {
            if (part == "HALT") 
            {
                haltFound = true;
            }
            if (!part.empty()) 
            {
                if (part[0] != ';') 
                {
                    if (part.back() != ':') 
                    {
                        auto colonPos = part.find(':');
                        if (colonPos != string::npos) 
                        {
                            int splitIndex = -1;
                            for (int idx = 0; idx < part.size(); ++idx) 
                            {
                                if (part[idx] == ':') 
                                {
                                    splitIndex = idx;
                                    break;
                                }
                            }   
                            tokens.push_back(part.substr(0, splitIndex + 1));
                            part = part.substr(splitIndex + 1);
                        }
                    }
                    if (part.back() == ';') 
                    {
                        part.pop_back();
                        tokens.push_back(part);
                        break;
                    }
                    tokens.push_back(part);
                }
            else 
            {
                break;
            }
        }
        else 
        {
            continue;
        }
    }
        string label, opcode, operand;
        int idx = 0;
        // Extract label, opcode, and operand
        if(opcode == "HALT" || label == "HALT" || operand == "HALT") haltFound = true;
        if (!tokens.empty() && tokens[idx].back() == ':') 
        {
            label = tokens[idx++].substr(0, tokens[idx - 1].size() - 1);
            label.pop_back();
        }
        if (idx < tokens.size()) opcode = tokens[idx++];
        if (idx < tokens.size()) operand = tokens[idx++];

        // Validate label and store line information
        if (!label.empty()) 
        {
            if (!validateLabel(label)) 
            {
                errorDetails.push_back({lineNumber, "Invalid label name"});
            }
            else if (labelAddressMap.count(label) && labelAddressMap[label].first != -1) 
            {
                errorDetails.push_back({lineNumber, "Duplicate label used"});
            } 
            else 
            {
                labelAddressMap[label] = {programCounter, lineNumber};
            }
        }

        // Check operation validity and handle operand checks
        bool isValid = false;
        if (!opcode.empty()) 
{
    if (instructionMap.count(opcode)) 
    {
        int operandCount = instructionMap[opcode].second;

        if (operandCount == 1 || operandCount == 2) 
        {
            if (operand.empty()) 
            {
                errorDetails.push_back({lineNumber, "Missing Operand"});
            } 
            else if (tokens.size() - idx > 0) 
            {
                errorDetails.push_back({lineNumber, "Extra Operand found"});
            } 
            else 
            {
                string validatedOperand = "";
                
                if (!validateLabel(operand)) 
                {
                    string tmpOperand = operand;
                    if (operand[0] == '+') 
                    {
                        validatedOperand += '+';
                        tmpOperand = operand.substr(1);
                    } 
                    else if (operand[0] == '-') 
                    {
                        validatedOperand += '-';
                        tmpOperand = operand.substr(1);
                    }

                    bool isOct = CheckIfOctal(tmpOperand);
                    bool isHex = CheckIfHex(tmpOperand);
                    bool isDec = CheckIfDecimal(tmpOperand);

                    string conversionResult = "";
                    if (isOct) 
                    {
                        conversionResult = convertOctalToDecimal(tmpOperand.substr(1));
                        validatedOperand += conversionResult;
                    } 
                    else if (isHex) 
                    {
                        conversionResult = convertHexToDecimal(tmpOperand.substr(2));
                        validatedOperand += conversionResult;
                    } 
                    else if (isDec) 
                    {
                        validatedOperand += tmpOperand;
                    } 
                    else 
                    {
                        validatedOperand = "";
                    }
                } 
                else 
                {
                    validatedOperand = operand;
                    if (labelAddressMap.count(operand)) 
                    {
                        labelUsageMap[operand].push_back(lineNumber);
                    } 
                    else 
                    {
                        labelAddressMap[operand] = {-1, lineNumber};
                        labelUsageMap[operand].push_back(lineNumber);
                    }
                }

                if (!validatedOperand.empty()) 
                {
                    operand = validatedOperand;
                    haltFound = true;
                } 
                else 
                {
                    errorDetails.push_back({lineNumber, "Invalid Label Format"});
                }
            }
        } 
        else if (operandCount == 0) 
        {
            if (operand.empty()) 
            {
                haltFound = true;
            } 
            else 
            {
                errorDetails.push_back({lineNumber, "Unexpected Operand in zero-operand command"});
            }
        }
    } 
    else 
    {
        errorDetails.push_back({lineNumber, "Unknown Command"});
    }
}


if (isValid) 
{
    if (opcode == "SET") 
    {
        if (!label.empty()) 
        {
            variableMap[label] = operand;
        } 
        else 
        {
            errorDetails.push_back({lineNumber, "Missing label"});
        }
    }
}
        
        // Update program counter
        programCounter += isValid ? 1 : 0;
        lineRecords.push_back({programCounter, label, opcode, operand});
    }

// Check if labels are declared and used correctly
for (auto label : labelAddressMap) 
{
    if (label.second.first == -1) 
    {
        for (auto lineNum : labelUsageMap[label.first]) 
        {
            errorDetails.push_back({lineNum, "Label not declared"});
        }
    } 
    else if (!labelUsageMap.count(label.first)) 
    {
        warningDetails.push_back({label.second.second, "Unused Label"});
    }
}

// Sort error and warning lists
sort(errorDetails.begin(), errorDetails.end());
sort(warningDetails.begin(), warningDetails.end());

// Create error log file
string errorFile = filename + ".log";
ofstream coutErrors(errorFile);
for (const auto& warning : warningDetails) 
{
    coutErrors << "Line: " << warning.position << " WARNING: " << warning.message << endl;
}
if (!haltFound) 
{
    coutErrors << "WARNING !! : HALT not found " << endl;
}
if (!errorDetails.empty()) 
{
    for (const auto& error : errorDetails) 
    {
        coutErrors << "Line: " << error.position << " ERROR: " << error.message << endl;
    }
    coutErrors.close();
} 
else 
{
    coutErrors << "No errors!" << endl;
    coutErrors.close();
}

// If no errors, proceed with listing generation and machine code writing
if (errorDetails.empty()) 
{
    int i = 0;
    while (i < lineRecords.size()) 
    {
        int programCounter = lineRecords[i].programCounter;
        string label = lineRecords[i].labelName;
        string mnemonic = lineRecords[i].operation;
        string operand = lineRecords[i].operandValue;

        if (!mnemonic.empty()) 
        {
            string result = "        ";
            if (instructionMap[mnemonic].second == 2) 
            {
                string hexValue, opcodeHex;
                if (labelAddressMap.count(operand)) 
                {
                    int offset = labelAddressMap[operand].first - (programCounter + 1);
                    hexValue = convertDecimalToHex(offset);
                    opcodeHex = hexValue.substr(2) + instructionMap[mnemonic].first;
                } 
                else 
                {
                    int decimalOperand = stoi(operand);
                    hexValue = convertDecimalToHex(decimalOperand);
                    opcodeHex = hexValue.substr(2) + instructionMap[mnemonic].first;
                }
                result = opcodeHex;
            } 
            else if (instructionMap[mnemonic].second == 1) 
            {
                if (mnemonic == "data") 
                {
                    int decimalOperand = stoi(operand);
                    result = convertDecimalToHex(decimalOperand);
                } 
                else if (mnemonic == "SET") 
                {
                    int decimalOperand = stoi(operand);
                    result = convertDecimalToHex(decimalOperand);
                } 
                else 
                {
                    string hexValue, opcodeHex;
                    if (labelAddressMap.count(operand)) 
                    {
                        int address = labelAddressMap[operand].first;
                        hexValue = convertDecimalToHex(address);
                        opcodeHex = hexValue.substr(2) + instructionMap[mnemonic].first;
                    } 
                    else 
                    {
                        int decimalOperand = stoi(operand);
                        hexValue = convertDecimalToHex(decimalOperand);
                        opcodeHex = hexValue.substr(2) + instructionMap[mnemonic].first;
                    }
                    result = opcodeHex;

                    if (variableMap.count(operand)) 
                    {
                        int variableValue = stoi(variableMap[operand]);
                        string variableHex = convertDecimalToHex(variableValue);
                        result = variableHex.substr(2) + instructionMap[mnemonic].first;
                    }
                }
            } 
            else if (instructionMap[mnemonic].second == 0) 
            {
                result = "000000" + instructionMap[mnemonic].first;
            }

            machineCodes.push_back(result);
            string formattedLine = label.empty() ? "" : label + ": ";
            formattedLine += mnemonic.empty() ? "" : mnemonic + " ";
            formattedLine += operand;
            string addressHex = convertDecimalToHex(programCounter);
            listingRecords.push_back({addressHex, result, formattedLine});
        } 
        else 
        {
            machineCodes.push_back("        ");
            string formattedLine = label.empty() ? "" : label + ": ";
            string addressHex = convertDecimalToHex(programCounter);
            listingRecords.push_back({addressHex, "        ", formattedLine});
        }

        i++;
    }

    // Generate listing file
    string listFile = filename + ".lst";
    ofstream coutList(listFile);
    for (const auto& record : listingRecords) 
    {
        coutList << record.address << " " << record.machineCode << " " << record.statement << endl;
    }
    coutList.close();

    // Write machine code to binary file
    ofstream machineCodeFile;
    string machineFile = filename + ".o";
    machineCodeFile.open(machineFile, ios::binary | ios::out);
    for (const auto& code : machineCodes) 
    {
        if (!code.empty() && code != "        ") 
        {
            unsigned int cur = static_cast<unsigned int>(stoi(convertHexToDecimal(code)));
            machineCodeFile.write(reinterpret_cast<const char*>(&cur), sizeof(unsigned int));
        }
    }
    machineCodeFile.close();
}
return 0;
}