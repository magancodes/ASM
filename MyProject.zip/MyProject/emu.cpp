#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <cctype>
using namespace std;

// Helper functions to check digits, alphabets, and label validity
bool isNumeric(char ch) {
    return (ch >= '0' && ch <= '9');
}

bool isAlpha(char ch) {
    return (tolower(ch) >= 'a' && tolower(ch) <= 'z');
}

bool isValidIdentifier(const string& identifier) {
    if (identifier.empty()) return false;
    if (!isAlpha(identifier[0])) return false;
    for (size_t i = 1; i < identifier.length(); ++i) {
        if (!isalnum(identifier[i]) && identifier[i] != '_') return false;
    }
    return true;
}

// Conversion functions for number systems
string convertToDecimalFromOctal(const string& octalStr) {
    int result = 0, multiplier = 1;
    for (int i = octalStr.size() - 1; i >= 0; --i) {
        result += (octalStr[i] - '0') * multiplier;
        multiplier *= 8;
    }
    return to_string(result);
}

string convertToDecimalFromHex(const string& hexStr) {
    int result = 0, power = 1;
    for (int i = hexStr.size() - 1; i >= 0; --i, power *= 16) {
        int digitValue = isdigit(hexStr[i]) ? hexStr[i] - '0' : tolower(hexStr[i]) - 'a' + 10;
        result += digitValue * power;
    }
    return to_string(result);
}

bool isValidDecimal(const string& value) {
    if (value.empty()) return false;
    size_t start = (value[0] == '+' || value[0] == '-') ? 1 : 0;
    return all_of(value.begin() + start, value.end(), ::isdigit);
}

bool isValidOctal(const string& value) {
    if (value.size() < 2 || value[0] != '0') return false;
    return all_of(value.begin() + 1, value.end(), [](char ch) { return ch >= '0' && ch <= '7'; });
}

bool isValidHexadecimal(const string& value) {
    if (value.size() < 3 || value.substr(0, 2) != "0x") return false;
    return all_of(value.begin() + 2, value.end(), [](char ch) { return isxdigit(ch); });
}

// Define the ISA operations
enum class OperationType { ALU, MEMORY, CONTROL };

struct Operation {
    string name;
    OperationType type;
    int operandCount;
};

unordered_map<string, Operation> operations = {
    {"ldc", {"ldc", OperationType::ALU, 1}},
    {"adc", {"adc", OperationType::ALU, 1}},
    {"ldl", {"ldl", OperationType::MEMORY, 2}},
    {"stl", {"stl", OperationType::MEMORY, 2}},
    {"ldnl", {"ldnl", OperationType::MEMORY, 2}},
    {"stnl", {"stnl", OperationType::MEMORY, 2}},
    {"add", {"add", OperationType::ALU, 0}},
    {"sub", {"sub", OperationType::ALU, 0}},
    {"shl", {"shl", OperationType::ALU, 0}},
    {"shr", {"shr", OperationType::ALU, 0}},
    {"adj", {"adj", OperationType::ALU, 1}},
    {"a2sp", {"a2sp", OperationType::CONTROL, 0}},
    {"sp2a", {"sp2a", OperationType::CONTROL, 0}},
    {"call", {"call", OperationType::CONTROL, 2}},
    {"return", {"return", OperationType::CONTROL, 0}},
    {"brz", {"brz", OperationType::CONTROL, 2}},
    {"brlz", {"brlz", OperationType::CONTROL, 2}},
    {"br", {"br", OperationType::CONTROL, 2}},
    {"halt", {"halt", OperationType::CONTROL, 0}},
    {"set", {"set", OperationType::ALU, 1}},
};

vector<int> machineCodes;
int memory[1 << 24]; // Memory storage
int A = 0, B = 0, PC = 0, SP = 0, instructionsExecuted = 0; // Registers
pair<int, int> rwPair; // Memory read/write tracking

// Infinite loop detection tracking
unordered_set<int> visitedPCs;  // Set to track visited PCs (program counters)

// Instruction functions
void ldc(int value) { B = A; A = value; }
void adc(int value) { A += value; }
void ldl(int offset) { B = A; A = memory[SP + offset]; rwPair = {SP + offset, 0}; }
void stl(int offset) { rwPair = {SP + offset, memory[SP + offset]}; memory[SP + offset] = A; A = B; }
void ldnl(int offset) { A = memory[A + offset]; rwPair = {SP + offset, 0}; }
void stnl(int offset) { rwPair = {SP + offset, memory[SP + offset]}; memory[A + offset] = B; }
void add(int value) { A += B; }
void sub(int value) { A = B - A; }
void shl(int value) { A = B << A; }
void shr(int value) { A = B >> A; }
void adj(int value) { SP += value; }
void a2sp(int value) { SP = A; A = B; }
void sp2a(int value) { B = A; A = SP; }
void call(int offset) { B = A; A = PC; PC += offset; }
void ret(int value) { PC = A; A = B; }
void brz(int offset) { if (A == 0) PC += offset; }
void brlz(int offset) { if (A < 0) PC += offset; }
void br(int offset) { PC += offset; }
void halt(int value) { exit(0); }

// Function to check for infinite loop
bool checkInfiniteLoop() {
    if (visitedPCs.find(PC) != visitedPCs.end()) {
        cout << "Infinite Loop Detected! PC = " << PC << endl;
        return true;
    }
    visitedPCs.insert(PC);
    return false;
}

// Function for running instructions
void executeInstruction(int currentLine) {
    int opcode = currentLine & 0xFF;
    int value = (currentLine - opcode) >> 8;
    ++instructionsExecuted;
    
    // Check for infinite loop before executing
    if (checkInfiniteLoop()) {
        exit(1); // Stop execution if infinite loop is detected
    }

    // Execute the corresponding function
    vector<void(*)(int)> funcs = {ldc, adc, ldl, stl, ldnl, stnl, add, sub, shl, shr, adj, a2sp, sp2a, call, ret, brz, brlz, br, halt};
    funcs[opcode](value);
    
    // Memory safety check
    if (PC < 0 || PC >= machineCodes.size() || instructionsExecuted > (1 << 24)) {
        cerr << "Error: Program execution exceeded limits!" << endl;
        exit(1);
    }
}

// Function to load the program and check if it's loaded correctly
void loadProgram(const string& filename) {
    ifstream file(filename, ios::in | ios::binary);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    int code;
    PC = 0;
    while (file.read(reinterpret_cast<char*>(&code), sizeof(int))) {
        machineCodes.push_back(code);
        memory[PC] = code;  // Store each line of code at the PC in memory
        cout << "Loaded code: " << code << " at memory[" << PC << "]" << endl;  // Debug output
        PC++;
    }
    PC = 0;  // Reset PC to start from the beginning for execution
    file.close();
}


// Run the program and trace the execution
void runProgram() {
    cout << "Program execution start:" << endl;
    while (PC < machineCodes.size()) {
        int currentLine = machineCodes[PC++];
        
        // Trace output for debugging
        cout << "PC = " << setw(8) << setfill('0') << hex << PC
             << ", SP = " << setw(8) << setfill('0') << hex << SP
             << ", A = " << setw(8) << setfill('0') << hex << A
             << ", B = " << setw(8) << setfill('0') << hex << B
             << ", Instruction: " << dec << currentLine << endl;
        
        // Execute the corresponding function
        executeInstruction(currentLine);
    }
    cout << "Program execution finished!" << endl;
}

// Function to wipe/reset state
void wipeState() {
    PC = 0;
    SP = 0;
    A = 0;
    B = 0;
    instructionsExecuted = 0;
    visitedPCs.clear();  // Clear the visited PC set to allow fresh execution
    fill(begin(memory), end(memory), 0);  // Reset memory
}

// Function to display ISA
void displayISA() {
    cout << "Instruction Set Architecture (ISA):" << endl;
    for (const auto& op : operations) {
        cout << op.second.name << " (" << (op.second.type == OperationType::ALU ? "ALU" :
                                              op.second.type == OperationType::MEMORY ? "MEMORY" : "CONTROL")
             << ") Operand Count: " << op.second.operandCount << endl;
    }
}

int main(int argc, char* argv[]) {
    if (argc <= 2) {
        cerr << "Usage: ./emu [command] filename.o" << endl;
        return 1;
    }

    string filename = argv[2];
    string command = argv[1];

    loadProgram(filename);

    if (command == "-trace") {
        runProgram();
        cout << instructionsExecuted << " instructions executed" << endl;
    } else if (command == "-before") {
        // Show memory dump before execution
        cout << "Memory Dump (Before Execution):" << endl;
        for (int i = 0; i < 20; ++i) {  // Print first 20 memory locations for preview
            cout << "Memory[" << i << "] = " << memory[i] << endl;
        }
    } else if (command == "-after") {
        // Show memory dump after execution
        cout << "Memory Dump (After Execution):" << endl;
        for (int i = 0; i < 20; ++i) {  // Print first 20 memory locations for preview
            cout << "Memory[" << i << "] = " << memory[i] << endl;
        }
    } else if (command == "-wipe") {
        wipeState();  // Reset registers, PC, and memory before execution
        cout << "State wiped before execution." << endl;
    } else if (command == "-isa") {
        displayISA();  // Display ISA
    } else if (command == "-read") {
        // Implement read operation (e.g., print contents of the file)
        ifstream file(filename, ios::in | ios::binary);
        if (file) {
            cout << "Reading file: " << filename << endl;
            int code;
            while (file.read(reinterpret_cast<char*>(&code), sizeof(int))) {
                cout << "Code: " << code << endl;
            }
        } else {
            cerr << "Error: Unable to read file!" << endl;
        }
    } else if (command == "-write") {
        // Implement write operation (e.g., write to the file)
        ofstream file(filename, ios::out | ios::binary);
        if (file) {
            cout << "Writing to file: " << filename << endl;
            // Example write operation: writing machine codes to the file
            for (const auto& code : machineCodes) {
                file.write(reinterpret_cast<const char*>(&code), sizeof(int));
            }
        } else {
            cerr << "Error: Unable to write to file!" << endl;
        }
    } else {
        cerr << "Invalid command" << endl;
        return 1;
    }

    return 0;
}
